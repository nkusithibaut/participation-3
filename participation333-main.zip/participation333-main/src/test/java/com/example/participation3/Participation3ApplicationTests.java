package com.example.participation3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Participation3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
