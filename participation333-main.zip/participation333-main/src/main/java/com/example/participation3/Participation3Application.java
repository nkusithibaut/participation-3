package com.example.participation3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Participation3Application {

	public static void main(String[] args) {
		SpringApplication.run(Participation3Application.class, args);
	}

}